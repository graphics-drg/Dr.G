1、确保机器 adb 连接成功，能正常使用adb root、adb remount、adb shell等基本指令

2、双击运行push_and_pull_dr-g.bat

3、将pull出来的对应时间文件夹中的dumpInfo.tar 上传给rk工程师
